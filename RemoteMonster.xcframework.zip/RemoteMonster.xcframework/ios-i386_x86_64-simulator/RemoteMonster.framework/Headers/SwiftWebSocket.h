/*
 * SwiftWebSocket (swiftwebsocket.h)
 *
 * Copyright (C) Josh Baker. All Rights Reserved.
 * Contact: @tidwall, joshbaker77@gmail.com
 *
 * This software may be modified and distributed under the terms
 * of the MIT license.  See the LICENSE file for details.
 *
 */

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double SwiftWebSocketVersionNumber;
FOUNDATION_EXPORT const unsigned char SwiftWebSocketVersionString[];
